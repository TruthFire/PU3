﻿
namespace PU3
{
    partial class Register
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Name_Input = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Surename_Input = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Dob_Input = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Pw1_Input = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Nickname_Input = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Pw2_Input = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ErrLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vardas:";
            // 
            // Name_Input
            // 
            this.Name_Input.Location = new System.Drawing.Point(12, 228);
            this.Name_Input.Name = "Name_Input";
            this.Name_Input.Size = new System.Drawing.Size(292, 23);
            this.Name_Input.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pavarde:";
            // 
            // Surename_Input
            // 
            this.Surename_Input.Location = new System.Drawing.Point(12, 290);
            this.Surename_Input.Name = "Surename_Input";
            this.Surename_Input.Size = new System.Drawing.Size(292, 23);
            this.Surename_Input.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(12, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "Gimimo data (Pvz. 2000.11.29)";
            // 
            // Dob_Input
            // 
            this.Dob_Input.Location = new System.Drawing.Point(12, 349);
            this.Dob_Input.Name = "Dob_Input";
            this.Dob_Input.Size = new System.Drawing.Size(292, 23);
            this.Dob_Input.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(80, 396);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 47);
            this.button1.TabIndex = 6;
            this.button1.Text = "Toliau";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Pw1_Input
            // 
            this.Pw1_Input.Location = new System.Drawing.Point(12, 111);
            this.Pw1_Input.Name = "Pw1_Input";
            this.Pw1_Input.PasswordChar = '•';
            this.Pw1_Input.Size = new System.Drawing.Size(292, 23);
            this.Pw1_Input.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(12, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 21);
            this.label4.TabIndex = 9;
            this.label4.Text = "Slaptažodis:";
            // 
            // Nickname_Input
            // 
            this.Nickname_Input.Location = new System.Drawing.Point(12, 49);
            this.Nickname_Input.Name = "Nickname_Input";
            this.Nickname_Input.Size = new System.Drawing.Size(292, 23);
            this.Nickname_Input.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(12, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 21);
            this.label5.TabIndex = 7;
            this.label5.Text = "Slapyvardis:";
            // 
            // Pw2_Input
            // 
            this.Pw2_Input.Location = new System.Drawing.Point(12, 168);
            this.Pw2_Input.Name = "Pw2_Input";
            this.Pw2_Input.PasswordChar = '•';
            this.Pw2_Input.Size = new System.Drawing.Size(292, 23);
            this.Pw2_Input.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(12, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 21);
            this.label6.TabIndex = 11;
            this.label6.Text = "Pakartokite slaptažodį:";
            // 
            // ErrLabel
            // 
            this.ErrLabel.AutoSize = true;
            this.ErrLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrLabel.Location = new System.Drawing.Point(138, 378);
            this.ErrLabel.Name = "ErrLabel";
            this.ErrLabel.Size = new System.Drawing.Size(0, 15);
            this.ErrLabel.TabIndex = 13;
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 465);
            this.Controls.Add(this.ErrLabel);
            this.Controls.Add(this.Pw2_Input);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Pw1_Input);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Nickname_Input);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Dob_Input);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Surename_Input);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Name_Input);
            this.Controls.Add(this.label1);
            this.Name = "Register";
            this.Text = "Registration";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Register_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Name_Input;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Surename_Input;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Dob_Input;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Pw1_Input;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Nickname_Input;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Pw2_Input;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label ErrLabel;
    }
}

